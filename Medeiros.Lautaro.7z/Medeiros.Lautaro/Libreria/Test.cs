using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria
{
  public class Test
  {
    public static string Saludar()
    {
      return "Hola mundo";
    }
  }
}
