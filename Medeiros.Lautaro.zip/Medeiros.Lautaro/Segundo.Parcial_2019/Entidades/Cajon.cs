using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades.SP
{
  public class Cajon<T> : ISerializar
  {
    protected int _capacidad;
    protected List<T> _elementos;
    protected double _precioUnitario;
    public event MiDelegado EventoPrecio;

    public List<T> Elementos
    {
      get
      {
        return this._elementos;
      }
    }

    public double PrecioTotal
    {
      get
      {
        return _precioUnitario * Elementos.Count;
      }
    }

    public Cajon()
    {
      this._elementos = new List<T>();
    }

    public Cajon(int capacidad)
      :this()
    {
      this._capacidad = capacidad;
    }

    public Cajon(double precioUnitario,int capacidad)
      :this(capacidad)
    {
      this._precioUnitario = precioUnitario;
    }

    public override string ToString()
    {
      StringBuilder retorno = new StringBuilder();
      retorno.AppendLine("Capacidad: " + this._capacidad);
      retorno.AppendLine("Cantidad de elementos: " + this.Elementos.Count);
      retorno.AppendLine("Precio total: " + this.PrecioTotal);
      foreach( T item in this.Elementos)
      {
        retorno.AppendLine(item.ToString());
      }
      return retorno.ToString();
    }

    public static Cajon<T> operator +(Cajon<T> cajon,T elemento)
    {
      if(cajon.Elementos.Count < cajon._capacidad)
      {
        cajon.Elementos.Add(elemento);
      }
      return cajon;
    }

    public bool Xml(string archivo)
    {
      XmlSerializer ser = new XmlSerializer(typeof(Cajon<T>));
      StreamWriter writer = new StreamWriter(archivo +".txt");
      try
      {
        ser.Serialize(writer, this);
        writer.Close();
      }
      catch(Exception e)
      {
        Console.Write(e.Message);
      }
      return false;
    }

    
  }
}
