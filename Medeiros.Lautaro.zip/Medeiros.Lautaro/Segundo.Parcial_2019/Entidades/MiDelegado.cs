using Entidades.SP;
public delegate void MiDelegado(Cajon<Banana> cajon);

