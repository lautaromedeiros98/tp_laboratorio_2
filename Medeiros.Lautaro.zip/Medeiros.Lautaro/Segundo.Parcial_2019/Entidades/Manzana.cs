using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades.SP
{
  public class Manzana : Fruta , ISerializar , IDeserializar
  {
    protected string _provinciaOrigen;

    public string Nombre
    {
      get
      {
        return "Manzana";
      }
    }

    public double Peso
    {
      get
      {
        return this._peso;
      }
    }

    public Manzana(string color,double peso,string provinciaOrigen)
      :base(color,peso)
    {
      this._provinciaOrigen = provinciaOrigen;
    }

    public override bool TieneCarozo
    {
      get
      {
        return true;
      }
    }

    protected override string FrutaToString()
    {
      return base.FrutaToString() + " Tiene carozo: " + this.TieneCarozo + " Provincia origen: " + this._provinciaOrigen;
    }

    public bool Xml(string archivo)
    {
      XmlSerializer ser = new XmlSerializer(typeof(Manzana));
      StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + archivo);
      try
      {
        ser.Serialize(writer, this);
        writer.Close();
        return true;
      }
      catch (Exception e)
      {
        Console.Write(e.Message);
      }
      return false;
    }

    bool IDeserializar.Xml(string archivo, out Fruta fruta)
    {
      XmlSerializer ser = new XmlSerializer(typeof(Fruta));
      StreamReader reader = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+archivo);
      fruta=(Fruta)ser.Deserialize(reader);
      reader.Close();
      return true;
    }
  }
}
