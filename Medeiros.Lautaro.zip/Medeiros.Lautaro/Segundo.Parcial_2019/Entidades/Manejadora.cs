using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Entidades.SP
{
  public class Manejadora
  {
    public void ManejadorPrecio(Cajon<Banana> cajon)
    {
        StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/EventoPrecio.txt");
        writer.WriteLine(DateTime.Now);
        writer.WriteLine("Precio del cajon: " + cajon.PrecioTotal);
        writer.Close();
    }
  }
}
